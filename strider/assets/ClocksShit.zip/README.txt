https://archive.org/details/me-make-acf-car-explain
Archive of Clock's ACF tutorial (it was taken down soon after ACF's spree of shit updates)
AND his E2s (in the provided Cock folder)
(I believe these are public since seemingly everyone on Mars has a fair bit of these-
- and I recall Mars staff implying they're public before so shrug )
